#include <Jogador.h>
#include <Elegoo_TFTLCD.h>

//definição das cores
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

Jogador::Jogador(int j) 
{
  //  XO Jogador 1
  //  OO
  playerID  = j;
  //tft = tftTemp;
  if(playerID == 1){
	posX = 10;
	posY = 10;
	cor = BLUE;
  }
  //  OX Jogador 2
  //  OO
  else if(playerID == 2){
	posX = 170;
	posY = 10;
	cor = RED;
  }
  //  OO Jogador 3
  //  XO
  else if(playerID == 3){
	posX = 10;
	posY = 130;
	cor = GREEN;
  }
  //  OO Jogador 4
  //  OX
  else if(playerID == 4){
	posX = 170;
	posY = 130;
	cor = YELLOW;
  }
  vida = 20;
  
}
void Jogador::ShowStatus(){
	tft.setCursor(posX, posY);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("P");
	tft.println(playerID);
	
	tft.setCursor(posX, posY+16);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("HP: ");
	tft.println(vida);
}

void Jogador::ShowBattleMenu(){
    tft.fillScreen(BLACK);

	tft.setCursor(15, 15);
	tft.setTextSize(4);
	tft.setTextColor(cor);
	tft.print("Jogador ");
	tft.println(playerID);
	
	tft.setCursor(15, 50);
	tft.setTextSize(3);
	tft.setTextColor(cor);
	tft.print("HP: ");
	tft.println(vida);
	
	BackButton();
}

void Jogador::BackButton(){
	tft.fillRect(0,180,80,60,cor); 
	tft.fillRect(35,205,25,10,BLACK);
	tft.fillTriangle(20,210,35,195,35,225,BLACK);
}










//void Jogador::ShowStatus(Elegoo_TFTLCD tft){
//	//tft.fillRect(posX,posY,90,50,WHITE);
//	tft.setCursor(posX, posY);
//	tft.setTextSize(2);
//	tft.setTextColor(cor);
//	tft.print("P");
//	tft.println(playerID);
//	
//	tft.setCursor(posX, posY+16);
//	tft.setTextSize(2);
//	tft.setTextColor(cor);
//	tft.print("HP: ");
//	tft.println(vida);
//}

//void Jogador::ShowBattleMenu(Elegoo_TFTLCD tft){
//    tft.fillScreen(BLACK);
//
//	tft.setCursor(15, 15);
//	tft.setTextSize(4);
//	tft.setTextColor(cor);
//	tft.print("Jogador ");
//	tft.println(playerID);
//	
//	tft.setCursor(15, 50);
//	tft.setTextSize(3);
//	tft.setTextColor(cor);
//	tft.print("HP: ");
//	tft.println(vida);
//	
//	BackButton(tft);
//}
//
//void Jogador::BackButton(Elegoo_TFTLCD tft){
//	tft.fillRect(0,180,80,60,cor); 
//	tft.fillRect(35,205,25,10,BLACK);
//	tft.fillTriangle(20,210,35,195,35,225,BLACK);
//}