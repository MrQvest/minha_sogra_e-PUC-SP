#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>

class Jogador
{
  int posX;
  int posY;
  int jogador;
  int vida;
  int cor;

  public:
  Jogador(int j, Elegoo_TFTLCD tft);
  void ShowStatus(Elegoo_TFTLCD tft);

  private:
};