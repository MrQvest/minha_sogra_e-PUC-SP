#include <Jogador.h>
#include <Elegoo_TFTLCD.h>

//definição das cores
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

Jogador::Jogador(int j, Elegoo_TFTLCD tft) 
{
  //  XO Jogador 1
  //  OO
  jogador = j;
  if(jogador == 1){
	posX = 10;
	posY = 10;
	cor = BLUE;
  }
  //  OX Jogador 2
  //  OO
  else if(jogador == 2){
	posX = 170;
	posY = 10;
	cor = RED;
  }
  //  OO Jogador 3
  //  XO
  else if(jogador == 3){
	posX = 10;
	posY = 130;
	cor = GREEN;
  }
  //  OO Jogador 4
  //  OX
  else if(jogador == 4){
	posX = 170;
	posY = 130;
	cor = YELLOW;
  }
  vida = 20;
  
}

void Jogador::ShowStatus(Elegoo_TFTLCD tft){
	//tft.fillRect(posX,posY,90,50,WHITE);
	tft.setCursor(posX, posY);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("P");
	tft.println(jogador);
	
	tft.setCursor(posX, posY+16);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("HP: ");
	tft.println(vida);
}