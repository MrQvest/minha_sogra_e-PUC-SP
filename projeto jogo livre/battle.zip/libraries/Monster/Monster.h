#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>

class Monster{
	int internalID;
	
	public: 
	Monster(int ID);
	void DrawMonster(Elegoo_TFTLCD tft);
	
	private:
}