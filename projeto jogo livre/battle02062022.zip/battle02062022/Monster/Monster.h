#include <Arduino.h>
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library

#ifndef MONSTER_H
#define MONSTER_H
class Monster{

	int internalID;
	int player;

	int loot;
	
	public: 
		int health;
		int isRandom;
		int damage;
		int minDamage;
		int maxDamage;
		String name;

		Monster();
		void FinalBoss();
		void newMonster(int ID, int p);
	
};

#endif