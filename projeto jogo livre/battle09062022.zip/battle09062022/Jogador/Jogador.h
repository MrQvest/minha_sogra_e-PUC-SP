#include <inttypes.h>
#include "Arduino.h"
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library
#include <Monster.h>

class Jogador
{
	int posX;
	int posY;
	int minDamage = 1;
	int maxDamage = 12;
	int level = 1;
	int xp = 0;
	int xpToNextLevel = 5;	
	int hurt;
	int enemyHurt;
	
  public:
	int cor;
  	int health;
	int armor;
	int damage;
	int extraDamage;
	int playerID;
	int enemyHealth;
	int enemyArmor;
	int enemyID;
	int enemyMinDmg;
	int enemyMaxDmg;
	int enemyDamage;
	int enemyColor;

	int lutando = 0;
	Monster monster = Monster();


	static Adafruit_TFTLCD tft;
	Jogador(int j);
	void ShowStatus();
	void ShowBattleMenu();
	void ShowMonsterMenu();
	void ShowMonsterBattle();
	void ShowMonsterBattle(Monster m);
	void ChoosePlayerBattle(int enemies[], int enemyColors[]);
	void ShowPlayerBattle(Jogador enemy);
	void ChangeHealth(int v);
	void ChangeArmor(int a);
	void ChangeDamage(int d);
	void Attack();
	void AttackPlayer();

  private:
	void BackButton();
	void BattleButton();
	void BossButton();
	void PlayerBattleButton();
	void HealthButton();
	void ArmorButton();
	void DamageButton();
	void AttackButton();
	void RollDamage();
	void RollDamagePlayer(int min, int max, int i);
	void LevelUp();
	void VictoryScreen();
	void DeathScreen();
};