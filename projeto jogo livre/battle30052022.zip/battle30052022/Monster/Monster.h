

class Monster{

	int internalID;
	int player;
	
	public: 
	int health;
	int damage;
	int loot;
	//String name;
	Monster(int p);
	newMonster(int level, int p);
	
	
};