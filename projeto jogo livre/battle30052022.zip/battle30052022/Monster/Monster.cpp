#include <Monster.h>


Monster::Monster(int p){
	player = p;
};

Monster::newMonster(int level, int p){
	//if (level == 1) internalID = random(1,35);
	if(internalID < 6){ //SLIME
		health = 3;
		damage = 1;
		loot = 0;
	}
};