#include <inttypes.h>
#include "Arduino.h"
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library
#include <Monster.h>

class Jogador
{
	int posX;
	int posY;
	int cor;
	int minDamage = 1;
	int maxDamage = 12;
	int level = 1;
	int xp = 0;
	int xpToNextLevel = 5;	
	int hurt;
	
  public:
  	int health;
	int armor;
	int damage;
	int extraDamage;
	int playerID;

	int lutando = 0;
	Monster monster = Monster();


	static Adafruit_TFTLCD tft;
	Jogador(int j);
	void ShowStatus();
	void ShowBattleMenu();
	void ShowMonsterMenu();
	void ShowMonsterBattle();
	void ShowMonsterBattle(Monster m);
	void ChangeHealth(int v);
	void ChangeArmor(int a);
	void ChangeDamage(int d);
	void Attack();

  private:
	void BackButton();
	void BattleButton();
	void BossButton();
	void HealthButton();
	void ArmorButton();
	void DamageButton();
	void AttackButton();
	void RollDamage();
	void LevelUp();
	void VictoryScreen();
	void DeathScreen();
};