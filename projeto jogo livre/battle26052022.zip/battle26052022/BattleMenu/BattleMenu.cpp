#include <BattleMenu.h>
#include <Jogador.h>
#include <Elegoo_TFTLCD.h>

//definição das cores
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

BattleMenu::BattleMenu(Jogador player){
	playerID = player.jogador;
	color = player.cor;
};

void ShowMenu(Elegoo_TFTLCD tft){
	tft.fillScreen(BLACK);
    tft.fillCircle(160,120,40,color);
}
 