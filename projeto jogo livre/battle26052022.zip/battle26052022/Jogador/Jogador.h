#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>

class Jogador
{
	int posX;
	int posY;
	int playerID;
	int vida;
	int cor;
	
  public:
	static Elegoo_TFTLCD tft;
	Jogador(int j);
	void ShowStatus();
	void ShowBattleMenu();
	void ShowMonsterMenu();
	void SetHealth(int v);

  private:
	void BackButton();
	void BattleButton();
	void HealthButton();
};