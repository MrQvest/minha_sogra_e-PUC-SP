#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>

class Jogador
{
	int posX;
	int posY;
	int playerID;
	int cor;
	
  public:
  	int health;
	int armor;
	static Elegoo_TFTLCD tft;
	Jogador(int j);
	void ShowStatus();
	void ShowBattleMenu();
	void ShowMonsterMenu();
	void ChangeHealth(int v);
	void ChangeArmor(int a);

  private:
	void BackButton();
	void BattleButton();
	void HealthButton();
	void ArmorButton();
};