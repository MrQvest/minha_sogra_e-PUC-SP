#include <Jogador.h>

#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library


//definição das cores
#define BLACK   0x0000
#define BLUE    0x001F
#define RED     0xF800
#define GREEN   0x07E0
#define CYAN    0x07FF
#define MAGENTA 0xF81F
#define YELLOW  0xFFE0
#define WHITE   0xFFFF

//PUBLIC

Jogador::Jogador(int j){
  //  XO Jogador 1
  //  OO
  playerID  = j;
  //tft = tftTemp;
  if(playerID == 1){
	posX = 10;
	posY = 10;
	cor = BLUE;
  }
  //  OX Jogador 2
  //  OO
  else if(playerID == 2){
	posX = 170;
	posY = 10;
	cor = RED;
  }
  //  OO Jogador 3
  //  XO
  else if(playerID == 3){
	posX = 10;
	posY = 130;
	cor = GREEN;
  }
  //  OO Jogador 4
  //  OX
  else if(playerID == 4){
	posX = 170;
	posY = 130;
	cor = YELLOW;
  }
  health = 20;
  armor = 0;
  extraDamage = 0;
  
}

void Jogador::ShowStatus(){
	tft.setCursor(posX, posY);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("P");
	tft.println(playerID);
	
	tft.setCursor(posX, posY+16);
	tft.setTextSize(2);
	tft.setTextColor(cor);
	tft.print("HP: ");
	tft.println(health);
	
	tft.setCursor(posX, posY+32);
	tft.setTextSize(2);
	tft.setTextColor(CYAN);
	tft.print("Armor: ");
	tft.println(armor);
	
	if(lutando == 1){
		tft.setCursor(posX, posY+90);
		tft.setTextSize(1);
		tft.setTextColor(WHITE);
		tft.println("[Batalhando...]");
	}
}

void Jogador::ShowBattleMenu(){
    tft.fillScreen(BLACK);

	tft.setCursor(15, 15);
	tft.setTextSize(4);
	tft.setTextColor(cor);
	tft.print("Jogador ");
	tft.println(playerID);
	
	HealthButton();
	ArmorButton();
	DamageButton();
	BackButton();
	BattleButton();
}

void Jogador::ShowMonsterMenu(){
	tft.fillScreen(BLACK);
	
	tft.setCursor(15, 15);
	tft.setTextSize(3);
	tft.setTextColor(cor);
	tft.println("Nivel de Monstro");
	tft.println("Nivel 0");
	tft.println("Nivel I");
	tft.println("Nivel II");
	tft.println("Nivel III");
	
	BackButton();
	BossButton();
}

void Jogador::ShowMonsterBattle(){
	tft.fillScreen(BLACK);
	
	tft.setCursor(15, 15);
	tft.setTextSize(3);
	tft.setTextColor(WHITE);
	tft.println(monster.name);
	tft.setCursor(95, 39);
	tft.setTextSize(2);
	tft.print("HP: ");
	tft.println(monster.health);
	tft.setCursor(95, 55);
	if(monster.isRandom == 1){
		tft.print("Damage:");
		tft.print(monster.minDamage);
		tft.print("-");
		tft.print(monster.maxDamage);
	}
	else{
		tft.print("Damage: ");
		tft.println(monster.damage);
	}
	
	tft.drawLine(0, 120, 400, 120, WHITE);
	
	tft.setCursor(15, 135);
	tft.setTextSize(3);
	tft.setTextColor(cor);
	tft.print("Jogador ");
	tft.println(playerID);
	tft.setCursor(95, 159);
	tft.setTextSize(2);
	tft.print("HP: ");
	tft.print(health);
	tft.setTextColor(CYAN);
	tft.print(" +");
	tft.println(armor);
	tft.setCursor(95, 175);
	tft.setTextColor(cor);
	tft.print("Damage:");
	tft.print(minDamage+extraDamage);
	tft.print("-");
	tft.print(maxDamage+extraDamage);

	
	AttackButton();
	BackButton();
}

void Jogador::ShowMonsterBattle(Monster m){
	monster = m;
	tft.fillScreen(BLACK);
	
	tft.setCursor(15, 15);
	tft.setTextSize(3);
	tft.setTextColor(WHITE);
	tft.println(monster.name);
	tft.setCursor(95, 39);
	tft.setTextSize(2);
	tft.print("HP: ");
	tft.println(monster.health);
	tft.setCursor(95, 55);
	if(monster.isRandom == 1){
		tft.print("Damage:");
		tft.print(monster.minDamage);
		tft.print("-");
		tft.print(monster.maxDamage);
	}
	else{
		tft.print("Damage: ");
		tft.println(monster.damage);
	}
	
	tft.drawLine(0, 120, 400, 120, WHITE);
	
	tft.setCursor(15, 135);
	tft.setTextSize(3);
	tft.setTextColor(cor);
	tft.print("Jogador ");
	tft.println(playerID);
	tft.setCursor(95, 159);
	tft.setTextSize(2);
	tft.print("HP: ");
	tft.print(health);
	tft.setTextColor(CYAN);
	tft.print(" +");
	tft.println(armor);
	tft.setCursor(95, 175);
	tft.setTextColor(cor);
	tft.print("Damage:");
	tft.print(minDamage+extraDamage);
	tft.print("-");
	tft.print(maxDamage+extraDamage);

	
	AttackButton();
	BackButton();
}

void Jogador::ChangeHealth(int v){
	health = health + v;
	tft.fillRect(15,50,150,21,BLACK);
	
	HealthButton();
	
}

void Jogador::ChangeArmor(int a){
	armor = armor + a;
	tft.fillRect(15,85,180,21,BLACK);
	
	ArmorButton();
}

void Jogador::ChangeDamage(int d){
	extraDamage = extraDamage + d;
	tft.fillRect(15,120,220,21,BLACK);
	
	DamageButton();
}


void Jogador::Attack(){
	//CALCULA O DANO E MOSTRA
	for(int i = 0; i < 15; i++){
		RollDamage();
		delay(i*20);
	}
	
	if(monster.damage < damage){
		monster.health = monster.health - damage + monster.damage;
		if(monster.health <= 0) {
			monster.health = 0;
			lutando = 0;
		}
		tft.setCursor(95, 39);
		tft.setTextColor(WHITE);
		tft.setTextSize(2);
		tft.print("HP: ");
		tft.fillRect(143, 39, 200, 14, BLACK);
		tft.println(monster.health);
	}
	if(monster.damage > damage){
		hurt = monster.damage - damage;
		while(armor>0 && hurt > 0){
			armor--;
			hurt--;
		}
		health = health - hurt;
		tft.fillRect(95, 159, 200, 14, BLACK);
		tft.setCursor(95, 159);
		tft.setTextSize(2);
		tft.setTextColor(cor);
		tft.print("HP: ");
		tft.print(health);
		tft.setTextColor(CYAN);
		tft.print(" +");
		tft.println(armor);
	}
}

//PRIVATE 

void Jogador::BackButton(){
	tft.fillRect(0,180,80,60,cor); 
	tft.fillRect(30,205,40,10,BLACK);
	tft.fillTriangle(15,210,30,195,30,225,BLACK);
}

void Jogador::BattleButton(){
	tft.fillRect(90,180,140,60,cor);
}

void Jogador::BossButton(){
	tft.fillRect(90,180,220,60,cor); 
	tft.setCursor(173, 185);
	tft.setTextColor(BLACK);
	tft.setTextSize(3);
	tft.println("Rei");
	tft.setCursor(119, 209);
	tft.println("Accursius");

}

void Jogador::HealthButton(){
	tft.setCursor(35, 50);
	tft.setTextSize(3);
	tft.setTextColor(cor);
	tft.print("HP:");
	tft.println(health);
	
	if(health>0)
		tft.fillTriangle(15,60,30,50,30,70,cor);
	if(health<20)
		tft.fillTriangle(141,60,126,50,126,70,cor);	
}

void Jogador::ArmorButton(){
	tft.setCursor(35, 85);
	tft.setTextSize(3);
	tft.setTextColor(CYAN);
	tft.print("Armor:");
	if(armor<10)tft.print(" ");
	tft.println(armor);
	
	if(armor>0)
		tft.fillTriangle(15,95,30,85,30,105,CYAN);
	//if(armor<20)
		tft.fillTriangle(197,95,182,85,182,105,CYAN);	
}

void Jogador::DamageButton(){
	tft.setCursor(35, 120);
	tft.setTextSize(3);
	tft.setTextColor(WHITE);
	tft.print("Dano +:");
	if(extraDamage<10 && extraDamage>-10)tft.print(" ");
	if(extraDamage>=0) tft.print("+");
	tft.println(extraDamage);
	
	//if(extraDamage>0)
		tft.fillTriangle(15,130,30,120,30,140,WHITE);
	//if(extraDamage<20)
		tft.fillTriangle(230,130,215,120,215,140,WHITE);	
}

void Jogador::AttackButton(){
	tft.fillCircle(260,120,30,WHITE);
}

void Jogador::RollDamage(){
	
	//CALCULA ATAQUE JOGADOR
	damage = random(minDamage+extraDamage, maxDamage+extraDamage+1);
	
	tft.fillRect(179,175,200,14,BLACK);
	tft.setCursor(95, 175);
	tft.setTextColor(cor);
	if(damage<10) tft.print("Damage: ");
	else tft.print("Damage:");
	tft.print(damage);
	
	//CALCULA ATAQUE MONSTRO
	if (monster.isRandom == 1) {
		monster.damage = random(monster.minDamage, monster.maxDamage+1);
		
		tft.fillRect(179,55,200,14,BLACK);
		tft.setCursor(95, 55);
		tft.setTextColor(WHITE);
		if(monster.damage<10) tft.print("Damage: ");
		else tft.print("Damage:");
		tft.print(monster.damage);
	}
}