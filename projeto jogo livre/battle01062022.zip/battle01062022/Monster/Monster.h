#include <Arduino.h>
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library

#ifndef MONSTER_H
#define MONSTER_H
class Monster{

	int internalID;
	int player;
	
	public: 
		int health;
		int damage;
		int loot;
		String name;
		Monster();
		void newMonster(int ID, int p);
	
};
#endif