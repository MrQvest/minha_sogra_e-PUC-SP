#include <inttypes.h>
#include "Arduino.h"
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library
#include <Monster.h>

class Jogador
{
	int posX;
	int posY;
	int cor;
	Monster monster = Monster();
	
  public:
  	int health;
	int armor;
	int damage;
	int playerID;

	static Adafruit_TFTLCD tft;
	Jogador(int j);
	void ShowStatus();
	void ShowBattleMenu();
	void ShowMonsterMenu();
	void ShowMonsterBattle(Monster m);
	void ChangeHealth(int v);
	void ChangeArmor(int a);
	void ChangeDamage(int d);

  private:
	void BackButton();
	void BattleButton();
	void HealthButton();
	void ArmorButton();
	void DamageButton();
};