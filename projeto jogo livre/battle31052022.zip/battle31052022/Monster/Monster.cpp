#include <Monster.h>

Monster::Monster(){//construtor

};
void Monster::newMonster(int ID, int p){ //gera novo monstro
	internalID = ID;
	player = p;
	if(internalID <= 6){ //SLIME
		health = 3;
		damage = 1;
		loot = 0;
		name = "Slime";
	}
	
	else if(internalID <= 8){ //SLIME DOURADO
		health = 4;
		damage = 1;
		loot = 1;
		name = "Slime Dourado";
	}
	
	else if(internalID <= 13){ //GOBLIN
		health = 5;
		damage = 2;
		loot = 0;
		name = "Goblin";
	}
	
	else if(internalID <= 18){ //GOBLIN COM ESPETO
		health = 5;
		damage = 3;
		loot = 0;
		name = "Goblin com Espeto";
	}
	
	else if(internalID <= 23){ //FILHOTE DE ARANHA
		health = 2;
		damage = 4;
		loot = 0;
		name = "Filhote de Aranha";
	}
	
	else if(internalID <= 28){ //ESQUELETO
		health = 3;
		damage = 3;
		loot = 0;
		name = "Esqueleto";
	}
	
	else if(internalID <= 30){ //MIMICO
		health = 4;
		damage = 2;
		loot = 1;
		name = "Bau Mimico";
	}
	
	else if(internalID <= 35){ //MORCEGO
		health = 1;
		damage = 5;
		loot = 0;
		name = "Morcego";
	}
};

