#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>

class Monster{
	int internalID;
	int player;
	
	public: 
	newMonster(int ID, int P);
	
	private:
}