#include <Monster.h>
#include <Elegoo_TFTLCD.h>

Monster::Monster(int ID, int p){
	internalID = ID;
	player = p;
}
