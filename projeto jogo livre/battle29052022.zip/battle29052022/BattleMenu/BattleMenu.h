#include <inttypes.h>
#include "Arduino.h"
#include <Elegoo_TFTLCD.h>
#include <Jogador.h>


class BattleMenu{
	
	int playerID;
	int playerHealth;
	int color;
	
	public:
	BattleMenu(Jogador player);
	void ShowMenu(Elegoo_TFTLCD tft);

}