#include <Monster.h>

Monster::Monster(){//construtor

};
void Monster::newMonster(int ID, int p){ //gera novo monstro
	internalID = ID;
	player = p;
	
	//NIVEL 0
	if(internalID <= 6){ //SLIME
		health = 3;
		isRandom = 0;
		damage = 3;
		loot = 0;
		name = "Slime";
	}
	
	else if(internalID <= 8){ //SLIME DOURADO
		health = 4;
		isRandom = 0;
		damage = 3;
		loot = 1;
		name = "Slime Dourado";
	}
	
	else if(internalID <= 13){ //GOBLIN
		health = 5;
		isRandom = 0;
		damage = 4;
		loot = 0;
		name = "Goblin";
	}
	
	else if(internalID <= 18){ //GOBLIN COM ESPETO
		health = 7;
		isRandom = 0;
		damage = 5;
		loot = 0;
		name = "Goblin com Espeto";
	}
	
	else if(internalID <= 23){ //FILHOTE DE ARANHA
		health = 2;
		isRandom = 0;
		damage = 4;
		loot = 0;
		name = "Filhote de Aranha";
	}
	
	else if(internalID <= 28){ //ESQUELETO
		health = 4;
		isRandom = 0;
		damage = 4;
		loot = 0;
		name = "Esqueleto";
	}
	
	else if(internalID <= 30){ //MIMICO
		health = 6;
		isRandom = 0;
		damage = 2;
		loot = 1;
		name = "Bau Mimico";
	}
	
	else if(internalID <= 35){ //MORCEGO
		health = 1;
		isRandom = 0;
		damage = 5;
		loot = 0;
		name = "Morcego";
	}
	
	//NIVEL I
	else if(internalID <= 37){ //LOBO
		health = 10;
		isRandom = 0;
		damage = 4;
		loot = 1;
		name = "Lobo";
	}
	
	else if(internalID <= 39){ //SAQUEADOR 
		health = 8;
		isRandom = 1;
		minDamage = 2;
		maxDamage = 8;
		loot = 1;
		name = "Saqueador";
	}
	
	else if(internalID <= 41){ //SLIME GIGANTE 
		health = 20;
		isRandom = 0;
		damage = 2;
		loot = 1;
		name = "Slime Gigante";
	}
	
	else if(internalID <= 43){ //ZUMBI
		health = 7;
		isRandom = 1;
		minDamage = 2;
		maxDamage = 6;
		loot = 1;
		name = "Zumbi";
	}
	
	else if(internalID <= 44){ //REI GOBLIN
		health = 6;
		isRandom = 0;
		damage = 5;
		loot = 1;
		name = "Rei Goblin";
	}
	
	//NIVEL II
	else if(internalID <= 46){ //CAVALEIRO
		health = 22;
		isRandom = 0;
		damage = 6;
		loot = 1;
		name = "Cavaleiro";
	}

	else if(internalID <= 48){ //ARANHONA
		health = 20;
		isRandom = 0;
		damage = 7;
		loot = 1;
		name = "Aranha Gigante";
	}
	
	else if(internalID <= 50){ //MAGO
		health = 23;
		isRandom = 1;
		minDamage = 3;
		maxDamage = 12;
		loot = 1;
		name = "Mago";
	}

	else if(internalID <= 52){ //LOBISOMEN
		health = 20;
		isRandom = 0;
		damage = 7;
		loot = 1;
		name = "Lobisomen";
	}

	else if(internalID <= 54){ //TROLL
		health = 20;
		isRandom = 1;
		minDamage = 4;
		maxDamage = 15;
		loot = 1;
		name = "Troll de Caverna";
	}
	
	//NIVEL III
	else if(internalID <= 56){ //CAVALEIRO CORROMPIDO
		health = 30;
		isRandom = 1;
		minDamage = 5;
		maxDamage = 15;
		loot = 2;
		name = "Cavaleiro Corrompido";
	}
	
	else if(internalID <= 59){ //MAGO SOMBRIO
		health = 20;
		isRandom = 1;
		minDamage = 6;
		maxDamage = 20;
		loot = 2;
		name = "Mago Sombrio";
	}

	else if(internalID <= 61){ //COVEIRO
		health = 30;
		isRandom = 1;
		minDamage = 4;
		maxDamage = 16;
		loot = 2;
		name = "Coveiro";
	}
	
	else if(internalID <= 63){ //PRINCIPE
		health = 25;
		isRandom = 1;
		minDamage = 3;
		maxDamage = 20;
		loot = 2;
		name = "Principe Perdido";
	}
};

void Monster::FinalBoss(){//construtor
	health = 50;
	isRandom = 1;
	minDamage = 5;
	maxDamage = 20;
	name = "Rei Accursius";
};