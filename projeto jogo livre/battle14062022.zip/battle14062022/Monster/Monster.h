#include <Arduino.h>
#include <SPFD5408_Adafruit_TFTLCD.h> // Hardware-specific library

#ifndef MONSTER_H
#define MONSTER_H
class Monster{

	int internalID;
	int player;


	
	public: 
		int health;
		int isRandom;
		int damage;
		int minDamage;
		int maxDamage;
		int xp;
		String name;
		int loot;

		Monster();
		void FinalBoss();
		void newMonster(int ID, int p);
	
};

#endif